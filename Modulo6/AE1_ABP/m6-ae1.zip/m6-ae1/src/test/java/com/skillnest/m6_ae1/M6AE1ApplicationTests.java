package com.skillnest.m6_ae1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M6Ae1ApplicationTests {

	@Test
	void contextLoads() {
		// Test de contexto Spring Boot
	}
}
